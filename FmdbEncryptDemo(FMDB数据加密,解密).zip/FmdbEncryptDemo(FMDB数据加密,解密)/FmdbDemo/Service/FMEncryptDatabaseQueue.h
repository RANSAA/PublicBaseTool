//
//  FMEncryptDatabaseQueue.h
//  FmdbDemo
//
//  Created by ZhengXiankai on 15/7/31.
//  Copyright (c) 2015年 ZhengXiankai. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabaseQueue.h"

@interface FMEncryptDatabaseQueue : FMDatabaseQueue


@end